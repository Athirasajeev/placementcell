-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.5.28 - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.3.0.4984
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping database structure for myspace
CREATE DATABASE IF NOT EXISTS `myspace` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `myspace`;


-- Dumping structure for table myspace.adminlogin
CREATE TABLE IF NOT EXISTS `adminlogin` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.adminlogin: ~2 rows (approximately)
DELETE FROM `adminlogin`;
/*!40000 ALTER TABLE `adminlogin` DISABLE KEYS */;
INSERT INTO `adminlogin` (`id`, `name`, `password`) VALUES
	(1, 'admin', 'admin'),
	(2, 'hari', 'vhs');
/*!40000 ALTER TABLE `adminlogin` ENABLE KEYS */;


-- Dumping structure for table myspace.comment
CREATE TABLE IF NOT EXISTS `comment` (
  `commentid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `postid` bigint(20) unsigned DEFAULT NULL,
  `commentuserid` bigint(20) unsigned DEFAULT NULL,
  `comment` varchar(500) DEFAULT NULL,
  `dateofcomment` datetime DEFAULT NULL,
  PRIMARY KEY (`commentid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.comment: ~12 rows (approximately)
DELETE FROM `comment`;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` (`commentid`, `postid`, `commentuserid`, `comment`, `dateofcomment`) VALUES
	(1, 2, 10, 'cool bike, where did you get this?', '2015-03-22 00:00:00'),
	(2, 2, 9, 'what is this , man,, what do you think about yourself', '2015-03-22 00:00:00'),
	(3, 3, 1, 'nice', '2015-07-26 00:00:00'),
	(4, 3, 1, 'hai', '2015-07-26 00:00:00'),
	(5, 16, 12, 'nyc', '2018-01-18 00:00:00'),
	(6, 16, 12, 'fantastic', '2018-01-31 00:00:00'),
	(7, 16, 12, 'fantastic', '2018-01-31 00:00:00'),
	(8, 18, 12, 'love you joy', '2018-01-31 00:00:00'),
	(9, 23, 15, 'happy being with friends', '2018-02-24 00:00:00'),
	(10, 26, 20, 'smiles on face', '2018-02-24 00:00:00'),
	(11, 29, 23, 'have fun...', '2018-02-24 00:00:00'),
	(12, 33, 27, 'miss you', '2018-02-24 00:00:00');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;


-- Dumping structure for table myspace.friendlist
CREATE TABLE IF NOT EXISTS `friendlist` (
  `friendlistid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` bigint(20) unsigned DEFAULT NULL,
  `friendid` bigint(20) unsigned DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0',
  `requesteddate` datetime DEFAULT NULL,
  `accepteddate` datetime DEFAULT NULL,
  PRIMARY KEY (`friendlistid`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.friendlist: ~61 rows (approximately)
DELETE FROM `friendlist`;
/*!40000 ALTER TABLE `friendlist` DISABLE KEYS */;
INSERT INTO `friendlist` (`friendlistid`, `userid`, `friendid`, `status`, `requesteddate`, `accepteddate`) VALUES
	(1, 10, 9, 1, '2015-03-22 00:00:00', '2015-03-22 00:00:00'),
	(2, 9, 11, 1, '2015-07-26 00:00:00', '2015-07-26 00:00:00'),
	(3, 13, 12, 1, '2018-01-18 00:00:00', '2018-01-18 00:00:00'),
	(4, 16, 12, 0, '2018-02-24 00:00:00', NULL),
	(5, 16, 13, 0, '2018-02-24 00:00:00', NULL),
	(6, 16, 14, 0, '2018-02-24 00:00:00', NULL),
	(7, 18, 12, 0, '2018-02-24 00:00:00', NULL),
	(8, 18, 13, 0, '2018-02-24 00:00:00', NULL),
	(9, 18, 14, 0, '2018-02-24 00:00:00', NULL),
	(10, 18, 16, 0, '2018-02-24 00:00:00', NULL),
	(11, 22, 12, 0, '2018-02-24 00:00:00', NULL),
	(12, 22, 13, 0, '2018-02-24 00:00:00', NULL),
	(13, 22, 13, 0, '2018-02-24 00:00:00', NULL),
	(14, 22, 14, 0, '2018-02-24 00:00:00', NULL),
	(15, 22, 15, 0, '2018-02-24 00:00:00', NULL),
	(16, 25, 12, 0, '2018-02-24 00:00:00', NULL),
	(17, 23, 22, 0, '2018-02-24 00:00:00', NULL),
	(18, 25, 13, 0, '2018-02-24 00:00:00', NULL),
	(19, 23, 16, 0, '2018-02-24 00:00:00', NULL),
	(20, 23, 13, 0, '2018-02-24 00:00:00', NULL),
	(21, 23, 12, 0, '2018-02-24 00:00:00', NULL),
	(22, 25, 15, 0, '2018-02-24 00:00:00', NULL),
	(23, 25, 17, 0, '2018-02-24 00:00:00', NULL),
	(24, 23, 20, 0, '2018-02-24 00:00:00', NULL),
	(25, 23, 25, 0, '2018-02-24 00:00:00', NULL),
	(26, 26, 25, 0, '2018-02-24 00:00:00', NULL),
	(27, 26, 12, 0, '2018-02-24 00:00:00', NULL),
	(28, 26, 13, 0, '2018-02-24 00:00:00', NULL),
	(29, 26, 15, 0, '2018-02-24 00:00:00', NULL),
	(30, 30, 25, 0, '2018-02-24 00:00:00', NULL),
	(31, 30, 12, 0, '2018-02-24 00:00:00', NULL),
	(32, 30, 13, 0, '2018-02-24 00:00:00', NULL),
	(33, 29, 16, 0, '2018-02-24 00:00:00', NULL),
	(34, 29, 13, 0, '2018-02-24 00:00:00', NULL),
	(35, 29, 18, 0, '2018-02-24 00:00:00', NULL),
	(36, 29, 26, 0, '2018-02-24 00:00:00', NULL),
	(37, 29, 27, 0, '2018-02-24 00:00:00', NULL),
	(38, 31, 25, 0, '2018-02-24 00:00:00', NULL),
	(39, 31, 12, 0, '2018-02-24 00:00:00', NULL),
	(40, 31, 13, 0, '2018-02-24 00:00:00', NULL),
	(41, 32, 33, 1, '2018-02-24 00:00:00', '2018-02-24 00:00:00'),
	(42, 32, 12, 0, '2018-02-24 00:00:00', NULL),
	(43, 34, 31, 0, '2018-02-24 00:00:00', NULL),
	(44, 34, 13, 0, '2018-02-24 00:00:00', NULL),
	(45, 34, 14, 0, '2018-02-24 00:00:00', NULL),
	(46, 35, 22, 0, '2018-02-24 00:00:00', NULL),
	(47, 35, 23, 0, '2018-02-24 00:00:00', NULL),
	(48, 35, 29, 0, '2018-02-24 00:00:00', NULL),
	(49, 37, 12, 0, '2018-02-24 00:00:00', NULL),
	(50, 37, 13, 0, '2018-02-24 00:00:00', NULL),
	(51, 35, 33, 0, '2018-02-24 00:00:00', NULL),
	(52, 37, 14, 0, '2018-02-24 00:00:00', NULL),
	(53, 38, 12, 0, '2018-02-24 00:00:00', NULL),
	(54, 38, 13, 0, '2018-02-24 00:00:00', NULL),
	(55, 38, 14, 0, '2018-02-24 00:00:00', NULL),
	(56, 42, 12, 0, '2018-02-24 00:00:00', NULL),
	(57, 42, 13, 0, '2018-02-24 00:00:00', NULL),
	(58, 42, 14, 0, '2018-02-24 00:00:00', NULL),
	(59, 45, 12, 0, '2018-02-24 00:00:00', NULL),
	(60, 45, 13, 0, '2018-02-24 00:00:00', NULL),
	(61, 45, 14, 0, '2018-02-24 00:00:00', NULL);
/*!40000 ALTER TABLE `friendlist` ENABLE KEYS */;


-- Dumping structure for table myspace.message
CREATE TABLE IF NOT EXISTS `message` (
  `Userid` bigint(20) unsigned DEFAULT NULL,
  `messagetouserid` bigint(20) unsigned DEFAULT NULL,
  `messagecontent` varchar(500) DEFAULT NULL,
  `dateofmessage` datetime DEFAULT NULL,
  `status` tinyint(3) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.message: ~8 rows (approximately)
DELETE FROM `message`;
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` (`Userid`, `messagetouserid`, `messagecontent`, `dateofmessage`, `status`) VALUES
	(10, 9, 'hi dinesh, how are you', '2015-03-22 00:00:00', 0),
	(9, 10, 'nothing da, fine', '2015-03-22 00:00:00', 0),
	(10, 9, 'then what the new things there', '2015-03-22 00:00:00', 0),
	(11, 9, 'asdda', '2015-07-26 00:00:00', 0),
	(9, 11, 'hlooo', '2015-07-26 00:00:00', 0),
	(11, 9, 'hai', '2015-07-26 00:00:00', 0),
	(12, 13, 'haiiii', '2018-01-18 00:00:00', 0),
	(13, 12, 'hello', '2018-01-18 00:00:00', 0);
/*!40000 ALTER TABLE `message` ENABLE KEYS */;


-- Dumping structure for table myspace.post
CREATE TABLE IF NOT EXISTS `post` (
  `postid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(20) unsigned DEFAULT NULL,
  `title` varchar(500) DEFAULT NULL,
  `dateofupload` datetime DEFAULT NULL,
  `imageif` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`postid`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.post: ~52 rows (approximately)
DELETE FROM `post`;
/*!40000 ALTER TABLE `post` DISABLE KEYS */;
INSERT INTO `post` (`postid`, `userid`, `title`, `dateofupload`, `imageif`) VALUES
	(8, 11, 'Boys Mass', '2015-07-26 00:00:00', 'DSC_0627.JPG'),
	(9, 9, 'Onam', '2015-07-26 00:00:00', 'DSC00507.JPG'),
	(10, 2, 'india', '2015-07-26 00:00:00', '09kit1.jpg'),
	(11, 2, 'Tour', '2015-07-26 00:00:00', 'DSC_0410.JPG'),
	(12, 11, 'champions', '2015-07-26 00:00:00', 'cricket-2608-inner1.jpg'),
	(13, 2, 'Sachin', '2015-07-27 00:00:00', 'tendulkar-bat-640x480.jpg'),
	(14, 1, 'New car', '2015-07-27 00:00:00', 'midhun (12).jpg'),
	(15, 1, 'cofee time', '2015-07-27 00:00:00', 'midhun (69).jpg'),
	(16, 13, 'eee', '2018-01-18 00:00:00', '2017-08-31-12-11-32-088.jpg'),
	(17, 13, '', '2018-01-18 00:00:00', ''),
	(18, 12, '', '2018-01-31 00:00:00', '4f55258f7d5c3b5f4d2823d2f095a4a4.jpg'),
	(19, 12, '', '2018-01-31 00:00:00', '4f55258f7d5c3b5f4d2823d2f095a4a4.jpg'),
	(20, 14, 'Happiness is in travelling', '2018-02-24 00:00:00', 'IMG20170926112523.jpg'),
	(21, 17, 'Thanks for wishes, Happy days', '2018-02-24 00:00:00', 'IMG-20170724-WA0024.jpg'),
	(22, 16, 'Iam so Happy today.', '2018-02-24 00:00:00', ''),
	(23, 15, 'clg iv', '2018-02-24 00:00:00', 'IMG_5268.JPG'),
	(24, 18, 'i feel so happy today', '2018-02-24 00:00:00', ''),
	(25, 19, 'Music is life # nostalgic sad', '2018-02-24 00:00:00', ''),
	(26, 20, 'something interesting', '2018-02-24 00:00:00', 'IMG_5850.JPG'),
	(27, 21, 'Lost , life is so miserserable', '2018-02-24 00:00:00', 'IMG20170926162322.jpg'),
	(28, 22, 'what a awkward day', '2018-02-24 00:00:00', ''),
	(29, 23, 'my class', '2018-02-24 00:00:00', 'IMG_5934.JPG'),
	(30, 25, 'awesome day with friends', '2018-02-24 00:00:00', 'Jessa 20160322_170402.jpg'),
	(31, 24, 'Missing', '2018-02-24 00:00:00', 'IMG_2500244858695.jpeg'),
	(32, 26, 'life is beautiful', '2018-02-24 00:00:00', ''),
	(33, 27, 'my family', '2018-02-24 00:00:00', 'Soolu 20171110_093015.jpg'),
	(34, 28, 'Depressed with life', '2018-02-24 00:00:00', 'IMG20170928084651.jpg'),
	(35, 30, 'so depressed', '2018-02-24 00:00:00', ''),
	(36, 29, 'miss you dear', '2018-02-24 00:00:00', 'IMG_20161008_114146.jpg'),
	(37, 31, 'Miss you so much', '2018-02-24 00:00:00', 'Delita Titus 20160318_164719.jpg'),
	(38, 32, 'food ,fun joyness', '2018-02-24 00:00:00', 'IMG20170927202729.jpg'),
	(39, 33, 'lonely', '2018-02-24 00:00:00', 'Ã¢â‚¬Âª+91 94961 71636Ã¢â‚¬Â¬ 20170321_184737.jpg'),
	(40, 34, 'Life is too short to worry.be happy', '2018-02-24 00:00:00', 'Sosa New 20160305_220508.jpg'),
	(41, 36, 'Happy . life is beautiful.', '2018-02-24 00:00:00', 'IMG20170511102105.jpg'),
	(42, 35, 'i am not well', '2018-02-24 00:00:00', 'Rinky 20170311_111945.jpg'),
	(43, 37, 'Alone life', '2018-02-24 00:00:00', 'Adhil PM 20160217_235800.jpg'),
	(44, 38, 'I feel so happy when iam with you dear', '2018-02-24 00:00:00', 'Pranav Krishna 20160223_221703.jpg'),
	(45, 39, 'silent tears holds the loudest pain', '2018-02-24 00:00:00', ''),
	(46, 40, 'i just want to die', '2018-02-24 00:00:00', ''),
	(47, 41, 'just want to escape from this hell.so sad', '2018-02-24 00:00:00', ''),
	(48, 42, 'so good life', '2018-02-24 00:00:00', ''),
	(49, 43, 'awesome life and iam enjoying it', '2018-02-24 00:00:00', ''),
	(50, 44, 'feeling fun', '2018-02-24 00:00:00', ''),
	(51, 45, 'positive life.positive thoughts', '2018-02-24 00:00:00', ''),
	(52, 46, 'being happy', '2018-02-24 00:00:00', ''),
	(53, 47, 'i feel loved and im so happy today', '2018-02-24 00:00:00', ''),
	(54, 48, 'i miss you so much dear. i want to be with you always', '2018-02-24 00:00:00', ''),
	(55, 49, 'feeling angry', '2018-02-24 00:00:00', ''),
	(56, 50, 'cool day and so happy', '2018-02-24 00:00:00', ''),
	(57, 51, 'feeling excited', '2018-02-24 00:00:00', ''),
	(58, 52, 'love you my dear soo much', '2018-02-24 00:00:00', 'Dona 20160111_210457.jpg'),
	(59, 53, 'so depressed and fed up', '2018-02-24 00:00:00', '');
/*!40000 ALTER TABLE `post` ENABLE KEYS */;


-- Dumping structure for table myspace.postlike
CREATE TABLE IF NOT EXISTS `postlike` (
  `postid` bigint(20) unsigned DEFAULT NULL,
  `likeuserid` bigint(20) unsigned DEFAULT NULL,
  `likestatus` tinyint(3) unsigned DEFAULT '1',
  `dateoflike` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.postlike: ~9 rows (approximately)
DELETE FROM `postlike`;
/*!40000 ALTER TABLE `postlike` DISABLE KEYS */;
INSERT INTO `postlike` (`postid`, `likeuserid`, `likestatus`, `dateoflike`) VALUES
	(1, 9, 1, '2015-03-22 00:00:00'),
	(8, 11, 1, '2015-07-26 00:00:00'),
	(8, 9, 1, '2015-07-26 00:00:00'),
	(9, 9, 1, '2015-07-26 00:00:00'),
	(9, 11, 1, '2015-07-26 00:00:00'),
	(16, 12, 1, '2018-01-18 00:00:00'),
	(17, 12, 1, '2018-01-31 00:00:00'),
	(29, 23, 1, '2018-02-24 00:00:00'),
	(34, 28, 1, '2018-03-04 00:00:00');
/*!40000 ALTER TABLE `postlike` ENABLE KEYS */;


-- Dumping structure for table myspace.user
CREATE TABLE IF NOT EXISTS `user` (
  `userid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `contactnumber` varchar(15) DEFAULT NULL,
  `emailid` varchar(150) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `userstatus` tinyint(3) unsigned DEFAULT '0',
  `profImage` varchar(50) DEFAULT 'noimage.png',
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;

-- Dumping data for table myspace.user: ~44 rows (approximately)
DELETE FROM `user`;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`userid`, `firstname`, `lastname`, `contactnumber`, `emailid`, `password`, `gender`, `userstatus`, `profImage`) VALUES
	(9, 'Dinesh', 'Balakrishnan', '9544856526', 'dinesh@gmail.com', 'dinesh', 'Male', 0, 'noimage.png'),
	(11, 'Harikrishnan', 'P H', '9400235060', 'hari@gmail.com', 'vhs', 'Male', 0, 'noimage.png'),
	(12, 'Annie', 'George', '9207904630', 'georgeannie614@gmail.com', '9847869597', 'Female', 0, '21272115_685843311610637_5208607795420578482_n.jpg'),
	(13, 'Aparna ', 'Upendran', '9544006551', 'aparnaupendran@gmail.com', 'appu123', 'Female', 0, 'IMG-20160401-WA0025.jpg'),
	(14, 'Aleesha', 'Mariyam', '8519381790', 'aleesha@gmail.com', 'aleesha', 'Female', 0, 'IMG20170927103809.jpg'),
	(15, 'Tony', 'Wilson', '9048889894', 'tonywilson@gmail.com', 'tonywilson', 'Male', 0, 'IMG_5400.JPG'),
	(16, 'Abhirami', 'Aji', '9658458629', 'abhirami@gmail.com', '1234', 'Female', 0, 'black.png'),
	(17, 'Balu ', 'M', '8289863451', 'balu@gmail.com', 'balu', 'Female', 0, 'IMG-20170724-WA0064.jpg'),
	(18, 'Ajay ', 'Joy', '9854263042', 'ajayjoy@gmail.com', '1234', 'Male', 0, '3ca02129fd2a74b94d5b1b67aaa5e2df.jpg'),
	(19, 'Cherian', 'Varkey', '8281215440', 'cherianv@gmail.com', 'cherian', 'Female', 0, '448180496.jpg'),
	(20, 'Tomson ', 'George', '7896544521', 'tomsongeorge@gmail.com', 'tomsongeorge', 'Male', 0, 'IMG_5849.JPG'),
	(21, 'Afnan', 'Nazer', '9747405795', 'afnan@gmail.com', 'afnan', 'Male', 0, 'IMG20170926133052.jpg'),
	(22, 'Alin', 'Baby', '9512475632', 'alinbaby@gmail.com', '1234', 'Male', 0, 'Achu Chechi 20160114_171114.jpg'),
	(23, 'Sreejith', 'P N', '4694969775', 'sreejithpn@gmail.com', 'sreejithpn', 'Male', 0, 'IMG_5126.JPG'),
	(24, 'Akash ', 'p Nambiar', '7736526352', 'akash@gmail.com', 'akash', 'Male', 0, 'DSC01377.JPG'),
	(25, 'Amal', 'Sebastian', '9556234562', 'amalsebastian@gmail.com', '1234', 'Male', 0, 'Achu Chechi 20160225_212648.jpg'),
	(26, 'Amal', 'Varghese', '9225631456', 'amalvarghese@gmail.com', '1234', 'Male', 0, 'Aby ikka 20160304_205732.jpg'),
	(27, 'Soolu ', 'Thomas', '9897456214', 'sooluthomas@gmail.com', 'sooluthomas', 'Female', 0, 'Soolu 20170927_080153.jpg'),
	(28, 'Akshaya', 'Suresh', '7594901960', 'akshaya@gmail.com', 'akshaya', 'Female', 0, 'IMG20170929063808.jpg'),
	(29, 'Sneha', 'Benoy', '7986574232', 'snehabenoy@gmail.com', 'snehabenoy', 'Female', 0, 'IMG_20161008_114140.jpg'),
	(30, 'Amal', 'Viju', '9885689568', 'amalviju@gmail.com', '1234', 'Male', 0, 'Achu Chechi 20160203_165450.jpg'),
	(31, 'Amith', 'S', '9556985698', 'amiths@gmail.com', '1234', 'Male', 0, 'Libin Paul 20160213_001549.jpg'),
	(32, 'Brijie', 'M', '8281227259', 'brijie@gmail.com', 'brijie', 'Female', 0, 'IMG20170925125024.jpg'),
	(33, 'Shincy', 'Sebastian', '9865457896', 'shincysebu@gmail.com', 'shincy', 'Female', 0, 'Ã¢â‚¬Âª+91 92075 93439Ã¢â‚¬Â¬ 20170224_203154.jpg'),
	(34, 'Amiya', 'Anna', '9665865986', 'amiyaanna@gmail.com', '1234', 'Female', 0, 'Amalettayi 20160311_211014.jpg'),
	(35, 'Sharon', 'Biju', '8746984785', 'sharonbiju@gmail.com', 'sharon', 'Male', 0, 'Ã¢â‚¬Âª+91 94961 71636Ã¢â‚¬Â¬ 20170216_193132.jpg'),
	(36, 'Cheloni', 'Shiv', '8281307985', 'cheloni@gmail.com', 'cheloni', 'Female', 0, 'IMG20170507153425.jpg'),
	(37, 'Anna ', 'Maria', '9445685965', 'annamaria@gmail.com', '1234', 'Female', 0, 'Achu Chechi 20160213_234034.jpg'),
	(38, 'Aravind', 'Jayan', '9662547852', 'aravindjayan@gmail.com', '1234', 'Male', 0, 'Blessi chechi A.G 20160218_212711.jpg'),
	(39, 'Aravind', 'Jojo', '9625346558', 'aravindjojo@gmail.com', '1234', 'Male', 0, 'Dona 20160111_210457.jpg'),
	(40, 'Arun', 'Raj', '9775869586', 'arunraj@gmail.com', '1234', 'Male', 0, 'Amal A2 20160131_151446.jpg'),
	(41, 'Ashly ', 'valsalan', '9225635623', 'ashlyvalsalan@gmail.com', '1234', 'Female', 0, 'Jerin Chettan ) 20160208_180017.jpg'),
	(42, 'Ashna', 'Paul', '9112532658', 'ashnapaul@gmail.com', '1234', 'Female', 0, 'Anu D 20160203_182022.jpg'),
	(43, 'Basil', 'Arackal', '9865794685', 'basilarackal@gmail.com', '1234', 'Male', 0, 'Jerin Chettan ) 20160209_140607.jpg'),
	(44, 'Bilna ', 'Siby', '9663526532', 'bilnasiby@gmail.com', '1234', 'Female', 0, 'Zoozoo-vjcet 20160309_011016.jpg'),
	(45, 'Benitta', 'Varkey', '9663365698', 'benittavarkey@gmail.com', '1234', 'Female', 0, 'Vjcet-Mittu 20160312_190350.jpg'),
	(46, 'Britto', 'Saji', '9445623356', 'brittosaji@gmail.com', '1234', 'Male', 0, 'Who-Jon-Snow-Mother-Game-Thrones.png'),
	(47, 'Cyriac', 'S', '9663255633', 'cyriacs@gmail.com', '1234', 'Male', 0, 'Achu Chechi 20160128_130240.jpg'),
	(48, 'Eldho ', 'Thampi', '9663322551', 'eldhothampi@gmail.com', '1234', 'Male', 0, 'Vjcet-Eldho 20160223_170934.jpg'),
	(49, 'Elsa ', 'Soju', '9663246358', 'elsasoju@gmail.com', '1234', 'Female', 0, 'Amal George 20160305_221629.jpg'),
	(50, 'Dennis', 'Thomas', '9856321478', 'dennisthomas@gmail.com', 'dennis123', 'Female', 0, 'Jerin Chettan ) 20160223_165027.jpg'),
	(51, 'Don', 'Davis', '9586231456', 'dondavis@gmail.com', 'don123', 'Male', 0, 'Sosa New 20160118_220217.jpg'),
	(52, 'Eldhose', 'Willson', '9875612349', 'eldhosewillson@gmail.com', 'eldhose123', 'Male', 0, 'Jerin Chettan ) 20160211_104956.jpg'),
	(53, 'Elvis', 'Sabu', '9654123658', 'elvissabu@gmail.com', 'elvis123', 'Male', 0, 'Mahin ikka 20160208_002929.jpg');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
